# Java_Project
Java project on Cafe Management system

##technology
Cafe Management System is a simple application using graphical components in the Swing toolkit in Java. 
 This whole system is built using Java programming language with the help of Eclipse IDE.

## Introduction:
Cafe Management system is simple application includes display available menu in cafe, calculating total bill amount of a customer.
Here you can select an item from the list and the user can enter a total quantity of selected item. 
After this, the system displays the total amount. In this application calculator is also provided so that user can manually calculate bill if he wish. 

## Feature:
1. Display Menu Card of cafe.
2. Select item and its quantity.
3. Calculate total bill.
4. Calculater is also provided for manually calculaitng bill.

## Screenshots of project

<img src="https://github.com/manjirikolte/Java_Project/blob/master/Cafe_system/Screen1.png" width="500" height="340">
<img src="https://github.com/manjirikolte/Java_Project/blob/master/Cafe_system/Screen%202.png" width="500" height="340">
